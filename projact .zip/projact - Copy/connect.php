<?php


if($open_connect != 1) {
    die(header('Location: form-login.php'));
}

$hostname = 'localhost';
$username = 'root';
$password = '';
$database = 'programmig_world';
$port = NULL;
$socket = NULL;
$connect = mysqli_connect($hostname, $username, $password, $database);
if(!$connect) {
    die("ການເຊື່ອມຕໍ່ລົ້ມເລວ : " . mysqli_connect_error($connect));
}else {
    mysqli_set_charset($connect, 'utf8');
}


?>