<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <div class="form-box">
    <h2>Register</h2>
    <form action="process-register.php" method="POST">
      <div class="input-box">
        <input type="text" name="username_account" required>
        <label>Username</label>
      </div>
      <div class="input-box">
        <input type="email" name="email_account" required>
        <label>Email</label>
      </div>
      <div class="input-box">
        <input type="password" name="password_account1" required>
        <label>Password</label>
      </div>
      <div class="input-box">
        <input type="password" name="password_account2" required>
        <label>Confirm Password</label>
      </div>
      <button type="submit" class="btn">Register</button>
      <p class="toggle-text">Already have an account? <a href="form-login.php">Login</a></p>
    </form>
  </div>
</body>
</html>
