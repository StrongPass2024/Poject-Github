<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <div class="form-box">
    <h2>Login</h2>
    <form action="process-login.php" method="POST"> <!-- ✅ เปลี่ยนตรงนี้ให้ถูก -->
      <div class="input-box">
        <input type="text" name="email_account" required> <!-- ✅ เพิ่ม name -->
        <label>Username</label>
      </div>
      <div class="input-box">
        <input type="password" name="password_account" required> <!-- ✅ เพิ่ม name -->
        <label>Password</label>
      </div>
      <button type="submit" class="btn">Login</button>
      <p class="toggle-text">Don't have an account? <a href="form-register.php">Register</a></p> <!-- ✅ ลิงก์ไปหน้า register -->
    </form>
  </div>
</body>
</html>
